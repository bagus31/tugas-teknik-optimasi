# algen
Algoritma Genetika
Implementasi algoritma genetika untuk penentuan parcel hari raya. 

INSTALASI
1. Pastikan sudah terinstal composer
2. Buat database algen di PHPMyadmin Anda
3. Jalankan file produk.sql di PHPMyadmin
4. Aktifkan apache dan mysql di Xampp
5. Buka tautan http://localhost/algen/
6. Masukkan budget yang dikehendaki
7. Algoritma genetika akan memberikan hasil

Tautan analisis di Excel https://docs.google.com/spreadsheets/d/1X06tKfq9zk1Kjy151SOYHFnVxpswkFQV/edit?usp=sharing&ouid=115047076800805745915&rtpof=true&sd=true