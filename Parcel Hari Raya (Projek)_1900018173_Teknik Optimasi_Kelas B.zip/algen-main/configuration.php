<?php

class Parameters
{
    const FILE_NAME = 'products.txt';
    const N = 10;
    const POPULATION_SIZE = 21;
    const COLUMNS = ['item', 'price'];
}
