<h2>Parcel Hari Raya menggunakan Algoritma Genetika</h2>
<hr>
<form method="post" action="<?= $_SERVER["PHP_SELF"]; ?>">

    Budget Rp <input type='text' name="inputBudget" autofocus>
    &nbsp;
    <input type="submit" name="submit" value="Submit">
    <p></p>

    Item. 
    &nbsp;
    <input type="checkbox" name="item1" value="Chitato">
    <label for="item">Chitato</label>
    &nbsp;
    <input type="checkbox" name="item2" value="Botan Mackarel">
    <label for="item">Botan Mackarel</label> 
    &nbsp;
    <input type="checkbox" name="item3" value="Teh Sosro">
    <label for="item">Teh Sosro</label>
    &nbsp;
    <input type="checkbox" name="item4" value="Keju Cheddar">
    <label for="item">Keju Cheddar</label>
    &nbsp;
    <input type="checkbox" name="item5" value="Palm Fruit Kurma 500gr">
    <label for="item">Palm Fruit Kurma 500gr</label>
    &nbsp;
    <input type="checkbox" name="item6" value="Marjan Syrup 460 ml">
    <label for="item">Marjan Syrup 460 ml</label>
    &nbsp;
    <input type="checkbox" name="item7" value="365 Wafer Stick 500 gr">
    <label for="item">365 Wafer Stick 500 gr</label>
    &nbsp;
    <input type="checkbox" name="item8" value="Nissin Biscuit Lemonia Twist 340 gr">
    <label for="item">Nissin Biscuit Lemonia Twist 340 gr</label>
    &nbsp;
    <input type="checkbox" name="item9" value="Kokola Wafer Cream 252 gr">
    <label for="item">Kokola Wafer Cream 252 gr</label>
    &nbsp;
    <input type="checkbox" name="item10" value="Sari Kacang Hijau 150 ml">
    <label for="item">Sari Kacang Hijau 150 ml</label>
    &nbsp;
    <input type="checkbox" name="item11" value="Pop Mie Pake Nasi 75 gr">
    <label for="item">Pop Mie Pake Nasi 75 gr</label>
    &nbsp;
    <input type="checkbox" name="item12" value="Teriyaki Saori 275 ml">
    <label for="item">Teriyaki Saori 275 ml</label>
    &nbsp;
    <input type="checkbox" name="item13" value="Dua Belibis Sambal 135/340/535 gr">
    <label for="item">Dua Belibis Sambal 135/340/535 gr</label>
    &nbsp;
    <input type="checkbox" name="item14" value="Teh Hijau Kepala Djenggot 60 gr">
    <label for="item">Teh Hijau Kepala Djenggot 60 gr</label>
    &nbsp;
    <input type="checkbox" name="item15" value="Madurasa 150 gr">
    <label for="item">Madurasa 150 gr</label>
    &nbsp;
    <input type="checkbox" name="item16" value="Makaroniku 200 gr">
    <label for="item">Makaroniku 200 gr</label>
    &nbsp;
    <input type="checkbox" name="item17" value="Ultra Low Fat Susu UHT 1000 ml">
    <label for="item">Ultra Low Fat Susu UHT 1000 ml</label>
    &nbsp;
    <input type="checkbox" name="item18" value="Khong Guan Malkist Salut Cokelat 120 gr">
    <label for="item">Khong Guan Malkist Salut Cokelat 120 gr</label>
    &nbsp;
    <input type="checkbox" name="item19" value="Kopi susu ABC">
    <label for="item">Kopi susu ABC</label>
    &nbsp;
    <input type="checkbox" name="item20" value="Coca cola">
    <label for="item">Coca cola</label>
    &nbsp;
    <input type="checkbox" name="item21" value="Khong guan">
    <label for="item">Khong guan</label>
    &nbsp;
    <input type="checkbox" name="item22" value="Danis Biscuit">
    <label for="item">Danis Biscuit</label>
    &nbsp;
    <p></p>

</form>

<?php
require 'vendor/autoload.php';

$maxBudget = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $maxBudget = $_POST["inputBudget"];

    if ($maxBudget === '') {
        echo '<font color =red>Enter your budget.</font>';
        die;
    }

    $main = new Main;
    $main->maxBudget = $maxBudget;
    $main->popSize = 10;
    $main->crossoverRate = 0.8;
    $main->maxGen = 250;
    $main->selectionType = 'elitism';
    $main->stoppingValue = 100;
    $main->numOfLastResult = 10;

    $result = $main->runMain();

    if (empty($result)) {
        echo 'Optimum solution was not found. Try again, or add more budget.';
    } else {
        echo "<table>";
        echo "<tr><td>Your budget</td><td>: <b>Rp. " . number_format($main->maxBudget) . "</b></td></tr>";
        echo "<tr><td>Optimum amount</td><td>: <b>Rp. " . number_format($result['amount'])  . "</b></td></tr>";
        echo "<tr><td>Number of items</td><td>: <b> " . $result['numOfItems'] . "</b></td></tr>";
        echo "</table>";

        echo "<br>List of items: <br>";
        echo "<table><tr><td>No.</td><td>Item</td><td>Price (Rp)</td></tr>";
        
        foreach ($result['items'] as $key => $item) {
            echo "<tr><td>" . ($key + 1) . "</td><td>" . $item[0] . "</td><td  style=align:right'>" . number_format($item[1]) . "</td></tr>";
        }
        echo "</table>";
    }
}

?>